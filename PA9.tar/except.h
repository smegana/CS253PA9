#ifndef EXCEPT_H
#define EXCEPT_H

#include <vector>
#include <string>

using namespace std;

string except(string, std::vector<std::string>, std::vector<std::string>);
bool ifExcept(string, std::vector<string>, std::vector<string>);

#endif
